import angular from 'angular';
import 'angular-touch';
import 'angular-animate';
import 'angular-cookies';
import 'angular-sanitize';
import 'angular-ui-router';
import 'angular-aria';

import 'script-loader!appkit-ui/dist/js/lightning.min.js';
