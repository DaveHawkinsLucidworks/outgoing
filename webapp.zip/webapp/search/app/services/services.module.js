import {CommonService} from './common.service.js';

export const ServicesModule = angular.module('as.services', [])
    // Uncomment .factory line below to add sample common service to the main app module.
    // This will inject any JS contained within into all views within the app.
    // .factory('CommonService', ['$lightningUrl', CommonService])
;
