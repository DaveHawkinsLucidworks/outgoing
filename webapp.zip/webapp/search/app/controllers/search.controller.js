/*@ngInject*/
export function SearchController($scope, $stateParams,$twigkit) {
    $scope.params = $stateParams;

    $twigkit.getUser()
        .then(function (user) {
            $scope.user = user;
        });

    $scope.logout = function() {
        window.location.href = "";
    }
    /**************************************************************************
     * Banners -- got these from Andy Tran's dcommerce demo! Thanks Andy!
     */

     $scope.bannerExist = function (response, zone) {
        // console.log('***bannerExist response=',response);
        if (!angular.isDefined(response)) {
            return false;
        }
        if (!angular.isDefined(response.messages)) {
            return false;
        }
        for (var i = 0; i < response.messages.length; i++) {
            var m = response.messages[i];
            if (m.type == 'banner') {
                var j = JSON.parse(m.value);
                var url = j.url;
                var z = j.zone;
                // console.log('***bannerExist found banner=', url, z);
                // if (z == zone) {
                return true;
                // }
            }
        }
        return false;
    };


    $scope.getBanner = function (response, zone) {
        if (!angular.isDefined(response)) {
            return false;
        }
        if (!angular.isDefined(response.messages)) {
            return false;
        }
        // console.log('***getbanner response=', response);
        for (var i = 0; i < response.messages.length; i++) {
            var m = response.messages[i];
            if (m.type == 'banner') {
                var j = JSON.parse(m.value);
                var url = j.url;
                var z = j.zone;
                // console.log('***getbanner found banner=', url, z);
                // if (z == zone) {
                return url;
                // }
            }
        }
        return false;
    };


    /**************************************************************************
     * Banners -- got these from Andy Tran's dcommerce demo! Thanks Andy!
     */

     $scope.spellchkExist = function (response, zone) {
        // console.log('***bannerExist response=',response);
        if (!angular.isDefined(response)) {
            return false;
        }
        if (!angular.isDefined(response.messages)) {
            return false;
        }
        for (var i = 0; i < response.messages.length; i++) {
            var m = response.messages[i];
            if (m.type == 'spelling') {
                //var url = j.url;
                //var z = j.zone;
                // console.log('***bannerExist found banner=', url, z);
                // if (z == zone) {
                return true;
                // }
            }
        }
        return false;
    };


    $scope.getSpellchk = function (response, zone) {
        if (!angular.isDefined(response)) {
            return false;
        }
        if (!angular.isDefined(response.messages)) {
            return false;
        }
        // console.log('***getbanner response=', response);
        for (var i = 0; i < response.messages.length; i++) {
            var m = response.messages[i];
            if (m.type == 'spelling') {
                var j = m.label;
                var url = j;
                //var z = j.zone;
                // console.log('***getbanner found banner=', url, z);
                // if (z == zone) {
                return url;
                // }
            }
        }
        return false;
    };  
}
