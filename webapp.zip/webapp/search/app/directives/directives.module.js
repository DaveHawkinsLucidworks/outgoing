import {SampleDirective} from "./sample.directive";

export const DirectivesModule = angular.module('as.directives', [])
    // Uncomment .directive line below to add sample directive to the main app module
    // NOTE: This directive is functionally dependant upon common.service.js inclusion in services.module.js
    // .directive('sample', SampleDirective)
;
